<ul class="list-unstyled">
                <li class="active"><a href="index.html"> <i class="icon-home"></i>Home </a>
                <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-windows"></i>Hotel Rooms </a>
                  <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
                    <li><a  href="<?php echo e(url('create_room')); ?>">Add Room</a></li>
                    <li><a  href="<?php echo e(url('view_room')); ?>">View Room</a></li>
     
                    <li><a href="#">Page</a></li>
                  </ul>
                </li>

      </nav><?php /**PATH C:\xampp\htdocs\hotel_booking_system\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>