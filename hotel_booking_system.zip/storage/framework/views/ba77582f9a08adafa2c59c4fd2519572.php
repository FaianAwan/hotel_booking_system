
<!DOCTYPE html>
<html lang="en">
   <head>
      <base href="/public">
      <?php echo $__env->make('home.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      
<style type="text/css">
  label {
    display: inline-block;
    width: 200px;
  }

  input {
    width: 100%;
  }
</style>

   </head>
   <body class="main-layout">
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <header>
         <?php echo $__env->make('home.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </header>

      <div class="our_room">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Our Room</h2>
                     <p>Lorem Ipsum available, but the majority have suffered </p>
                  </div>
               </div>
            </div>

            <div class="row">
               <div class="col-md-8">
                  <div id="serv_hover" class="room">
                     <div style="padding:20px" class="room_img">
                        <img style="height: 300px; width:800px" src="/room/<?php echo e($room->image); ?>" alt="#"/>
                     </div>
                  </div>
                  <div class="bed_room">
                     <h3><?php echo e($room->room_title); ?></h3>
                     <p style="padding: 12px"><?php echo e($room->description); ?></p>
                     <h4 style="padding: 12px"> Free wifi : <?php echo e($room->wifi); ?></h4>
                     <h4 style="padding: 12px"> Room Type : <?php echo e($room->room_type); ?></h4>
                     <h3 style="padding: 12px"> Price: <?php echo e($room->price); ?></h3>
                  </div>
               </div>
               
               <div class="col-md-4">
                  <h1 style="font-size: 40px!important;">Book Room</h1> 
                  
                     <form action="<?php echo e(url('add_booking/' . $room->id)); ?>" method="POST">

    <?php echo csrf_field(); ?>
   
   
                  <div>
                     <label>Name</label>
                     <input type="text" name="name">
                  </div>

                  <div>
                     <label>Email</label>
                     <input type="email" name="email">
                  </div>

                  <div>
                     <label>Phone</label>
                     <input type="number" name="phone">
                  </div>
                  <div>
                     <label>Start Date</label>
                     <input type="date" name="startDate" id="startDate">
                  </div>

                  <div>
                     <label>End Date</label>
                     <input type="date" name="endDate" id="endDate">
                  </div>

                  <div>
                     <input type="submit" class="btn btn-primary" value="Book Room">
                  </div>
                  </form>  
               </div>
            </div>
         </div>
      </div>
       
      <?php echo $__env->make('home.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script type="text/javascript">
   $(function(){
  var dtToday = new Date();

  var month = dtToday.getMonth() + 1;
  var day = dtToday.getDate();
  var year = dtToday.getFullYear();

  if(month < 10)
    month = '0' + month.toString();

  if(day < 10)
    day = '0' + day.toString();

  var maxDate = year + '-' + month + '-' + day;
  $('#startDate').attr('min', maxDate);
  $('#endDate').attr('min', maxDate);
});

</script>



   </body>
</html>
<?php /**PATH C:\xampp\htdocs\hotel_booking_system\resources\views/home/room_details.blade.php ENDPATH**/ ?>