          <!DOCTYPE html>
<html lang="en">
   <head>
      <?php echo $__env->make('home.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <!-- end loader -->
      <!-- header -->         
      <header>
        <?php echo $__env->make('home.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </header>
      <!-- end header inner -->
      <!-- end header -->
      <!-- banner -->
      <?php echo $__env->make('home.slider', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- end banner -->
      <!-- about -->
      <?php echo $__env->make('home.about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- end about -->
      <!-- our_room -->
      <?php echo $__env->make('home.room', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- end our_room -->
      <!-- gallery -->
     <?php echo $__env->make('home.galary', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>      <!-- end gallery -->
      <!-- blog -->
     <?php echo $__env->make('home.blog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- end blog -->
      <!--  contact -->
      <?php echo $__env->make('home.contact', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <!-- end contact -->
      <!--  footer -->
     <?php echo $__env->make('home.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
   </body>
</html><?php /**PATH C:\xampp\htdocs\hotel_booking_system\resources\views/home/index.blade.php ENDPATH**/ ?>